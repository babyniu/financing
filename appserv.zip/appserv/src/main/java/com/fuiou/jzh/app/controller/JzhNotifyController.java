package com.fuiou.jzh.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * Created by Crazz on 2/2/16.
 */
@Controller
public class JzhNotifyController {

    @ResponseBody
    @RequestMapping(path="/notify/api_front",method = RequestMethod.POST)
    public String apiFront(@RequestParam Map<String,String> param){
        System.out.println("/notify/api_front invoked");
        List<String> list = new ArrayList<String>();
        for(Map.Entry<String,String> entry:param.entrySet()){
            list.add("<h3>"+entry.toString()+"</h3>");
        }
        String div = StringUtils.collectionToDelimitedString(list,"");
        return String.format("<html><body>%s</body></html>",div);
    }

    @ResponseBody
    @RequestMapping(path="/notify/api_back",method = RequestMethod.POST)
    public String apiBack(@RequestParam Map<String,String> param){
        System.out.println("/notify/api_back invoked");
        List<String> list = new ArrayList<String>();
        for(Map.Entry<String,String> entry:param.entrySet()){
            list.add(entry.toString());
        }
        String div = StringUtils.collectionToDelimitedString(list,"\n");
        System.out.println(div);
        return "";
    }
}
