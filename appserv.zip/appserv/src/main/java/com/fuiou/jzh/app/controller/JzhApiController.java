package com.fuiou.jzh.app.controller;

import com.fuiou.jzh.app.global.AppConst;
import com.fuiou.jzh.app.model.JzhApiResp;
import com.fuiou.jzh.app.utils.ApiUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Crazz on 2/2/16.
 */
@Controller
public class JzhApiController {


    //商户APP个人用户免登录注册
    @ResponseBody
    @RequestMapping(path="/jzh/appWebReg",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public String appWebReg(){
        JzhApiResp apiResp  = new JzhApiResp();
        Map<String, String> formData = new HashMap<String, String>(5);
        formData.put("mchnt_cd", AppConst.MCHNT_CD);
        formData.put("mchnt_txn_ssn", ApiUtils.genSSN());
        formData.put("user_id_from","");
        formData.put("mobile_no","");
        formData.put("cust_nm","");
        formData.put("certif_tp","");
        formData.put("certif_id","");
        formData.put("email","");
        formData.put("city_id","");
        formData.put("parent_bank_id","");
        formData.put("bank_nm","");
        formData.put("back_notify_url",AppConst.MCHNT_BACK_NOTIFY_URL_BACK);
        formData.put("capAcntNo","");
        ApiUtils.sign(formData);//添加签名
        apiResp.setFormData(formData);
        apiResp.setRespCode(JzhApiResp.RSP_SUCCESS);
        apiResp.setRespDesc("success");
        return apiResp.toString();
    }


    //商户APP个人用户免登录快速充值
    @ResponseBody
    @RequestMapping(path="/jzh/api500001",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public String api500001(){
        JzhApiResp apiResp  = new JzhApiResp();
        Map<String, String> formData = new HashMap<String, String>(5);
        formData.put("mchnt_cd", AppConst.MCHNT_CD);
        formData.put("mchnt_txn_ssn", ApiUtils.genSSN());
        formData.put("login_id","13522622358");
        formData.put("amt","100");
        formData.put("page_notify_url",AppConst.MCHNT_BACK_NOTIFY_URL_FRONT);
        formData.put("back_notify_url",AppConst.MCHNT_BACK_NOTIFY_URL_BACK);
        ApiUtils.sign(formData);
        apiResp.setFormData(formData);
        apiResp.setRespCode(JzhApiResp.RSP_SUCCESS);
        apiResp.setRespDesc("success");
        return apiResp.toString();
    }

    //商户APP个人用户免登录快捷充值
    @ResponseBody
    @RequestMapping(path="/jzh/api500002",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public String api500002(){
        JzhApiResp apiResp  = new JzhApiResp();
        Map<String, String> formData = new HashMap<String, String>(5);
        formData.put("mchnt_cd", AppConst.MCHNT_CD);
        formData.put("mchnt_txn_ssn", ApiUtils.genSSN());
        formData.put("login_id","13522622358");
        formData.put("amt","100");
        formData.put("page_notify_url",AppConst.MCHNT_BACK_NOTIFY_URL_FRONT);
        formData.put("back_notify_url",AppConst.MCHNT_BACK_NOTIFY_URL_BACK);
        ApiUtils.sign(formData);
        apiResp.setFormData(formData);
        apiResp.setRespCode(JzhApiResp.RSP_SUCCESS);
        apiResp.setRespDesc("success");
        return apiResp.toString();
    }

    //商户APP个人用户免登录提现
    @ResponseBody
    @RequestMapping(path="/jzh/api500003",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public String api500003(){
        JzhApiResp apiResp  = new JzhApiResp();
        Map<String, String> formData = new HashMap<String, String>(5);
        formData.put("mchnt_cd", AppConst.MCHNT_CD);
        formData.put("mchnt_txn_ssn", ApiUtils.genSSN());
        formData.put("login_id","13522622358");
        formData.put("amt","100");
        formData.put("page_notify_url",AppConst.MCHNT_BACK_NOTIFY_URL_FRONT);
        formData.put("back_notify_url",AppConst.MCHNT_BACK_NOTIFY_URL_BACK);
        ApiUtils.sign(formData);
        apiResp.setFormData(formData);
        apiResp.setRespCode(JzhApiResp.RSP_SUCCESS);
        apiResp.setRespDesc("success");
        return apiResp.toString();
    }

    //商户APP个人用户免登录换手机号
    @ResponseBody
    @RequestMapping(path="/jzh/api400101",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public String api400101(){
        JzhApiResp apiResp  = new JzhApiResp();
        Map<String, String> formData = new HashMap<String, String>(5);
        formData.put("mchnt_cd", AppConst.MCHNT_CD);
        formData.put("mchnt_txn_ssn", ApiUtils.genSSN());
        formData.put("login_id","13522622358");
        formData.put("page_notify_url",AppConst.MCHNT_BACK_NOTIFY_URL_FRONT);
        formData.put("back_notify_url",AppConst.MCHNT_BACK_NOTIFY_URL_BACK);
        ApiUtils.sign(formData);
        apiResp.setFormData(formData);
        apiResp.setRespCode(JzhApiResp.RSP_SUCCESS);
        apiResp.setRespDesc("success");
        return apiResp.toString();
    }

    //商户APP个人用户签约
    @ResponseBody
    @RequestMapping(path="/jzh/appSign",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public String appSign(){
        JzhApiResp apiResp  = new JzhApiResp();
        Map<String, String> formData = new HashMap<String, String>(5);
        formData.put("mchnt_cd", AppConst.MCHNT_CD);
        formData.put("mchnt_txn_ssn", ApiUtils.genSSN());
        formData.put("login_id","13522622358");
        formData.put("page_notify_url",AppConst.MCHNT_BACK_NOTIFY_URL_FRONT);
        formData.put("back_notify_url",AppConst.MCHNT_BACK_NOTIFY_URL_BACK);
        ApiUtils.sign(formData);
        apiResp.setFormData(formData);
        apiResp.setRespCode(JzhApiResp.RSP_SUCCESS);
        apiResp.setRespDesc("success");
        return apiResp.toString();
    }


}
